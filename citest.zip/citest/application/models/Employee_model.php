<?php
class Employee_model extends CI_Model {

    public function get_employee()
    {
        $employeeQry = "SELECT * FROM `employee` ORDER BY employee_id DESC";
		$employeeRes = $this->db->query($employeeQry);
        return $employeeRes;
    }
}


?>