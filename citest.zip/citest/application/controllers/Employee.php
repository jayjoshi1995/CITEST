<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Employee_model');
		$this->load->database();
	}

	public function index()
	{
		$employeeRes = $this->Employee_model->get_employee();
		$employeeData["employeeData"] = $employeeRes->result_array();
		$this->load->view('employee',$employeeData);
	}

	public function saveEmployee(){
		$first_name = $this->input->post("first_name");
		$last_name = $this->input->post("last_name");
		$email = $this->input->post("email");
		$mobile_no = $this->input->post("mobile_no");
		$address = $this->input->post("address");
		$gender = $this->input->post("gender");
		if(isset($_POST["hobby"])){
			$hobby = implode(",",$_POST["hobby"]);
		}else{
			$hobby = "";
		}

		$config['upload_path']          = './images/';
		$config['allowed_types']        = 'gif|jpg|png';

		if($first_name==""){
			$responce["status"] = "false";
			$responce["message"] = "Please enter first name";
			echo json_encode($responce);
			return false;
		}
		if($last_name==""){
			$responce["status"] = "false";
			$responce["message"] = "Please enter last name";
			echo json_encode($responce);
			return false;
		}
		if($email==""){
			$responce["status"] = "false";
			$responce["message"] = "Please enter email";
			echo json_encode($responce);
			return false;
		}
		
		$photo = "";
		if ($_FILES['photo']['name']!="") {
			$this->load->library('upload', $config);
			if ( ! $this->upload->do_upload('photo'))
			{
				$responce["status"] = "false";
				$responce["message"] =$this->upload->display_errors();
				echo json_encode($responce);
				return false;
			}
			else
			{
				$photoName = $this->upload->data();
				$photo = $photoName["file_name"];
			}
		}

		$employee_data = array(
			"first_name"=>$first_name,
			"last_name"=>$last_name,
			"email"=>$email,
			"mobile"=>$mobile_no,
			"address"=>$address,
			"gender"=>(string)$gender,
			"hobby"=>$hobby,
			"photo"=>$photo
		);
		
		$this->db->insert("employee",$employee_data);
		$responce["status"] = "true";
		$responce["message"] = "Employee addedd successfully.";
		echo json_encode($responce);
		return false;
	}

	public function deleteEmployee(){
		$employee_id = $this->input->post("employee_id");

		$employeeQry = "SELECT photo FROM `employee` WHERE employee_id='".$employee_id."'";
		$employeeRes = $this->db->query($employeeQry);
		$employeeRow = $employeeRes->result_array();
		$photo = $employeeRow[0]["photo"];
		if($photo!=""){
			unlink("./images/".$photo);
		}
		$employeeQry = "DELETE FROM `employee` WHERE employee_id='".$employee_id."'";
		$employeeRes = $this->db->query($employeeQry);
		$responce["status"] = "true";
		$responce["message"] = "Employee has been deleted successfully.";
		echo json_encode($responce);
		return false;
	}

	public function editEmployee($employee_id){
		$employeeQry = "SELECT * FROM `employee` WHERE employee_id='".$employee_id."'";
		$employeeRes = $this->db->query($employeeQry);
		$employeeData["employeeData"] = $employeeRes->row();
		$this->load->view('editemployee',$employeeData);
	}

	public function updateEmployee(){
		$employee_id = $this->input->post("employee_id");
		$old_img = $this->input->post("old_img");
		$first_name = $this->input->post("first_name");
		$last_name = $this->input->post("last_name");
		$email = $this->input->post("email");
		$mobile_no = $this->input->post("mobile_no");
		$address = $this->input->post("address");
		$gender = $this->input->post("gender");
		if(isset($_POST["hobby"])){
			$hobby = implode(",",$_POST["hobby"]);
		}else{
			$hobby = "";
		}

		$config['upload_path']          = './images/';
		$config['allowed_types']        = 'gif|jpg|png';

		if($first_name==""){
			$responce["status"] = "false";
			$responce["message"] = "Please enter first name";
			echo json_encode($responce);
			return false;
		}
		if($last_name==""){
			$responce["status"] = "false";
			$responce["message"] = "Please enter last name";
			echo json_encode($responce);
			return false;
		}
		if($email==""){
			$responce["status"] = "false";
			$responce["message"] = "Please enter email";
			echo json_encode($responce);
			return false;
		}
		
		$WHERE = "";
		if ($_FILES['photo']['name']!="") {
			$this->load->library('upload', $config);
			if ( ! $this->upload->do_upload('photo'))
			{
				$responce["status"] = "false";
				$responce["message"] =$this->upload->display_errors();
				echo json_encode($responce);
				return false;
			}
			else
			{
				if($old_img!=""){
					unlink("./images/".$old_img);
				}
				$photoName = $this->upload->data();
				$WHERE = ",photo='".$photoName["file_name"]."'";
			}
		}

		$employeeQry = "UPDATE `employee` SET first_name='".$first_name."',last_name='".$last_name."',email='".$email."',mobile='".$mobile_no."',address='".$address."',gender='".(string)$gender."',hobby='".$hobby."' ".$WHERE." WHERE employee_id='".$employee_id."'";
		$employeeRes = $this->db->query($employeeQry);
		$responce["status"] = "true";
		$responce["message"] = "Employee updated successfully.";
		echo json_encode($responce);
		return false;
	}
}
