<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Employee List</title>
	<script src="<?php echo base_url()."assets/js/jquery-3.7.1.min.js"; ?>"></script>
</head>
<body>

<div id="container">
	<h1>Employee List</h1>
	<table style="border: 1px solid #0c0506; margin: 30px auto; width: 600px; padding: 0; border-spacing: none;width:100%" cellspacing="0" cellpadding="0" border="1">
		<thead>
			<tr>
				<th>Id</th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
				<th>Mobile No</th>
				<th>Address</th>
				<th>Gender</th>
				<th>Hobby</th>
				<th>Photo</th>
				<th>Register Data</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php
			if(count($employeeData)>0){
				for($i=0;$i<count($employeeData);$i++){
					$employee_id = $employeeData[$i]["employee_id"];
					$first_name = $employeeData[$i]["first_name"];
					$last_name = $employeeData[$i]["last_name"];
					$email = $employeeData[$i]["email"];
					$mobile = $employeeData[$i]["mobile"];
					$address = $employeeData[$i]["address"];
					$create_date = $employeeData[$i]["create_date"];
					$gender = "FeMale";
					if($employeeData[$i]["gender"]=="0"){
						$gender = "Male";
					}
					$hobby = $employeeData[$i]["hobby"];
					$photo =  "";
					if($employeeData[$i]["photo"]!=""){
						$photo = base_url()."images/".$employeeData[$i]["photo"];
					}

					?><tr>
						<td><?php echo $employee_id; ?></td>
						<td><?php echo $first_name; ?></td>
						<td><?php echo $last_name; ?></td>
						<td><?php echo $email; ?></td>
						<td><?php echo $mobile; ?></td>
						<td><?php echo $address; ?></td>
						<td><?php echo $gender; ?></td>
						<td><?php echo $hobby; ?></td>
						<td>
							<?php
							if($photo!=""){
								?>
								<img src="<?php echo $photo; ?>" style="width:80px;height:80px;">
							<?php
							}else{
								?>
								No Images Found
								<?php
							}
							?>
						</td>
						<td><?php echo $create_date; ?></td>
						<td><a href="<?php echo site_url('Employee/editEmployee/'.$employee_id); ?>" >Edit</a>|<a href="javascript:void(0);" data-id="<?php echo $employee_id; ?>" class="removeEmployee">Delete</a></td>
					</tr>
					<?php
				}
			}else{?>
			<tr>
				<td colspan="11" align="center">No Employee Found</td>
			</tr>
				<?php
			}
			?>
			
		</tbody>
	</table>

	<h1>Add Employee</h1>
	<form name="employee" id="employee" enctype="multipart/form-data" method="post">
		<label for="">First Name:*</label>
		<input type="text" name="first_name" id="first_name" value="">
		<br/>
		<label for="">Last Name:*</label>
		<input type="text" name="last_name" id="last_name" value="">
		<br/>
		<label for="">Email:*</label>
		<input type="email" name="email" id="email" value="">
		<br/>
		<label for="">Mobile No:</label>
		<input type="text" name="mobile_no" id="mobile_no" value="" maxlength="10">
		<br/>
		<label for="">Address:</label>
		<textarea name="address" id="address"></textarea>
		<br/>
		<label for="">Gender:</label>
		Male
		<input type="radio" name="gender" id="gender" value="0">
		Female
		<input type="radio" name="gender" id="gender" value="1">
		<br/>
		<label for="">Hobby:</label>
		Cricket<input type="checkbox" name="hobby[]" id="hobby" value="Cricket">
		Football<input type="checkbox" name="hobby[]" id="hobby" value="Football">
		Movie<input type="checkbox" name="hobby[]" id="hobby" value="Movie">
		<br/>
		<label for="">Photo:</label>
		<input type="file" name="photo" id="photo">
		<br/><br/>
		<button type="button" onclick="submitEmployee()" name="saveEmployee" id="saveEmployee">Submit</button>
	</form>
</div>
<script>
	function submitEmployee(){
		var first_name = $("#first_name").val();
		var last_name = $("#last_name").val();
		var email = $("#email").val();
		if(first_name==""){
			alert("Please enter first name");
			return false;
		}
		if(last_name==""){
			alert("Please enter last name");
			return false;
		}
		if(email==""){
			alert("Please enter email");
			return false;
		}

		var form = $('#employee')[0];
        var formData = new FormData(form);
		console.log(formData);
		$.ajax({
			url: "<?php echo site_url('Employee/saveEmployee'); ?>",
			type: "post",
			dataType: "JSON",
			data: formData,
			processData: false,
			contentType: false,
			success: function (data, status)
			{
				if(data.status=="false"){
					alert(data.message);
					return false;
				}else{
					alert(data.message);
					window.location.href = "<?php echo base_url('index.php'); ?>/Employee";
				}
			}
		});    
	}
	$(document).on("click", ".removeEmployee", function(){
		var employee_id = $(this).attr("data-id");
		if(employee_id!=""){
			if (confirm("Are you sure you want to delete employee?") == true){
				$.ajax({
					url: "<?php echo site_url('Employee/deleteEmployee'); ?>",
					type: "post",
					dataType: "JSON",
					data: {employee_id:employee_id},
					success: function (data, status)
					{
						alert(data.message);
						window.location.href = "<?php echo base_url('index.php'); ?>/Employee";
					}
				});  
			}
		}
	});

</script>
</body>
</html>
