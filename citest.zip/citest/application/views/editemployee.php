<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Employee</title>
	<script src="<?php echo base_url()."assets/js/jquery-3.7.1.min.js"; ?>"></script>
</head>
<body>
<?php
$hobby = explode(",",$employeeData->hobby);
$photo = "";
if($employeeData->photo!=""){
	$photo = base_url()."images/".$employeeData->photo;
}
?>
<div id="container">
	<h1>Edit Employee</h1>
	<form name="employee" id="employee" enctype="multipart/form-data" method="post">
		<label for="">First Name:*</label>
		<input type="hidden" name="employee_id" id="employee_id" value="<?php echo $employeeData->employee_id; ?>">
		<input type="hidden" name="old_img" id="old_img" value="<?php echo $employeeData->photo; ?>">
		<input type="text" name="first_name" id="first_name" value="<?php echo $employeeData->first_name; ?>">
		<br/>
		<label for="">Last Name:*</label>
		<input type="text" name="last_name" id="last_name" value="<?php echo $employeeData->last_name; ?>">
		<br/>
		<label for="">Email:*</label>
		<input type="email" name="email" id="email" value="<?php echo $employeeData->email; ?>">
		<br/>
		<label for="">Mobile No:</label>
		<input type="text" name="mobile_no" id="mobile_no" value="<?php echo $employeeData->mobile; ?>" maxlength="10">
		<br/>
		<label for="">Address:</label>
		<textarea name="address" id="address"><?php echo $employeeData->address; ?></textarea>
		<br/>
		<label for="">Gender:</label>
		Male
		<input type="radio" name="gender" id="gender" value="0" <?php if($employeeData->gender=="0") echo "checked='checked'"; ?>>
		Female
		<input type="radio" name="gender" id="gender" value="1" <?php if($employeeData->gender=="1") echo "checked='checked'"; ?>>
		<br/>
		<label for="">Hobby:</label>
		Cricket<input type="checkbox" name="hobby[]" id="hobby" value="Cricket" <?php if(in_array("Cricket",$hobby)) echo "checked='checked'"; ?>>
		Football<input type="checkbox" name="hobby[]" id="hobby" value="Football" <?php if(in_array("Football",$hobby)) echo "checked='checked'"; ?>>
		Movie<input type="checkbox" name="hobby[]" id="hobby" value="Movie" <?php if(in_array("Movie",$hobby)) echo "checked='checked'"; ?>>
		<br/>
		<label for="">Photo:</label>
		<input type="file" name="photo" id="photo">
		<?php
		if($photo!=""){
			?>
			<img src="<?php echo $photo; ?>">
			<?php
		}
		?>
		<br/><br/>
		<button type="button" onclick="submitEmployee()" name="saveEmployee">Submit</button>

		<button type="button" onclick="backEmployee()">Back</button>
	</form>
	
</div>
<script>
	function submitEmployee(){
		var first_name = $("#first_name").val();
		var last_name = $("#last_name").val();
		var email = $("#email").val();
		if(first_name==""){
			alert("Please enter first name");
			return false;
		}
		if(last_name==""){
			alert("Please enter last name");
			return false;
		}
		if(email==""){
			alert("Please enter email");
			return false;
		}

		var form = $('#employee')[0];
        var formData = new FormData(form);
		console.log(formData);
		$.ajax({
			url: "<?php echo site_url('Employee/updateEmployee'); ?>",
			type: "post",
			dataType: "JSON",
			data: formData,
			processData: false,
			contentType: false,
			success: function (data, status)
			{
				if(data.status=="false"){
					alert(data.message);
					return false;
				}else{
					alert(data.message);
					window.location.href = "<?php echo base_url('index.php'); ?>/Employee";
				}
			}
		});    
	}
	function backEmployee(){
		window.location.href = "<?php echo base_url('index.php'); ?>/Employee";
	}

</script>
</body>
</html>
